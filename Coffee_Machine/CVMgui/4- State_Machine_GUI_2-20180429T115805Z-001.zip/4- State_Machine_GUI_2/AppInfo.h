#ifndef APPINFO_H
#define APPINFO_H

#define APPNAME "Cola Vending Machine"

#define MAJOR_VERSION "0"
#define MINOR_VERSION "1"
#define REVISION_VERSION "0"
#define VERSION MAJOR_VERSION "." MINOR_VERSION "." REVISION_VERSION
#define APPNAME_VERSION APPNAME " v" VERSION
//#define APPNAME_VERSION "Cola Vending Machine v.0.1.0"

#endif
