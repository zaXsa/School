#include "MainWindow.h"
#include "StateMachine.h"

//********************* Mealy Actions

state_e StateMachine::ae_start(){
   return S_INIT;
}

state_e StateMachine::ae_init(){
   return S_WAIT_FOR_COINS;
}

state_e StateMachine::ae_5_cents(){
   money += 5;
   return S_CHECK_AMOUNT;
}

state_e StateMachine::ae_10_cents(){
   money += 10;
   return S_CHECK_AMOUNT;
}

state_e StateMachine::ae_20_cents(){
   money += 20;
   return S_CHECK_AMOUNT;
}

state_e StateMachine::ae_50_cents(){
   money += 50;
   return S_CHECK_AMOUNT;
}

state_e StateMachine::ae_money_enough(){
   return S_COLA;
}

state_e StateMachine::ae_money_notenough(){
   return S_WAIT_FOR_COINS;
}

// ********************* Moore Actions

event_e StateMachine::as_start(){
   return E_SEQ;
}

event_e StateMachine::as_init(){
   money = 0.0;
   pDialog->setDisplay("Enter your coins please");
   pDialog->enableCentButtons(true);
   return E_SEQ;
}

event_e StateMachine::as_wait_for_coins(){
   return E_NO;
}

event_e StateMachine::as_check_amount(){
   if (money >= priceCola) {
      return E_MONEY_ENOUGH;
   }
   else {
      return E_MONEY_NOTENOUGH;
   }
}

event_e StateMachine::as_cola(){
   pDialog->setLogger("\t Cola is delivered");
   return E_SEQ;
}

event_e StateMachine::as_change(){
   pDialog->setLogger(" \t change (cents):" +  QString::number(money - priceCola));
   return E_SEQ;
}

void StateMachine::handleEvent(event_e eventIn) {
   while (eventIn != E_NO){
      state_e nextState = S_NO; // temproray variable used by this function
      event_e eventOut = E_NO;  // temproray variable used by this function

      // Sequential states must sent E_SEQ .
      // Sequential stepping ends with sending E_NO (= eventOut).

      //***************************************************************** current state

      switch(currentState) {
         case S_START:
            pDialog->setLogger("-state (with event): Start");
            nextState = ae_start();
            break;

         case S_INIT:
            pDialog->setLogger("-state (with event): Init");
            nextState = ae_init();
            break;

         case S_WAIT_FOR_COINS:
            pDialog->setLogger("-state (with event): Wait for coins");
            switch(eventIn) {
               case E_IN5C:
                  pDialog->setLogger("\t 5 Cents inserted");
                  nextState = ae_5_cents();
                  break;
               case E_IN10C:
                  pDialog->setLogger("\t 10 Cents inserted");
                  nextState = ae_10_cents();
                  break;
               case E_IN20C:
                  pDialog->setLogger("\t 20 Cents inserted");
                  nextState = ae_20_cents();
                  break;
               case E_IN50C:
                  pDialog->setLogger("\t 50 Cents inserted");
                  nextState = ae_50_cents();
                  break;
               default:
                  pDialog->setLogger("S_WAIT_FOR_COINS System ERROR: Unknown event");
                  break;
            }

            break; //outer

         case S_CHECK_AMOUNT:
            pDialog->setLogger("-state (with event): Check amount");

            switch(eventIn){
               case E_MONEY_ENOUGH:
                  pDialog->setLogger("\t Enough money");
                  nextState = ae_money_enough();
                  break;
               case E_MONEY_NOTENOUGH:
                  pDialog->setLogger("\t Not enough money");
                  nextState = ae_money_notenough();
                  break;
               default:
                  pDialog->setLogger("S_CHECK_AMOUNT System ERROR: Unknown event");
                  break;
            }
            break; //outer

         case S_COLA:
            pDialog->setLogger("-state (with event): COLA");
            nextState = S_CHANGE;
            break;

         case S_CHANGE:
            pDialog->setLogger("-state (with event): CHANGE");
            nextState = S_INIT;
            break;
      }


      //***************************************************************** next state

      switch(nextState){
         case S_START:
            pDialog->setLogger("-state: Start");
            eventOut = as_start();
            break;

         case S_INIT:
            pDialog->setLogger("-state: Init");
            eventOut = as_init();
            break;

         case S_WAIT_FOR_COINS:
            pDialog->setLogger("-state: Wait for coins");
            eventOut = as_wait_for_coins(); // Go waiting for external events: event driven
            break;

         case S_CHECK_AMOUNT:
            pDialog->setLogger("-state: Check amount");
            eventOut = as_check_amount();
            break;

         case S_COLA:
            pDialog->setLogger("-state: COLA");
            eventOut = as_cola();
            break;

         case S_CHANGE:
            pDialog->setLogger("-state: CHANGE");
            eventOut = as_change();
            break;

         default:
            pDialog->setLogger("Statemachine System ERROR: Unknown state");
            eventOut = E_NO;
            break;
      }

      currentState = nextState;
      eventIn = eventOut;
   }
   return;
}




