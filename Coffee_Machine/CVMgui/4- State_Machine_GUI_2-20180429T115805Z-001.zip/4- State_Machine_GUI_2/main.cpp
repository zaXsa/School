#include "MainWindow.h"
#include <QApplication>
#include <string>
#include <iostream>

int main(int argc, char *argv[])
{
   // (1)
   QApplication a(argc, argv);
   // (2)
   MainWindow w;
   // (3)
   w.show();
   // (4)
  return a.exec();
}

//(1)  create an QApplication object. QApplication is derived from QDialog
//(2)  create your own window. The default constructor will initialise the the window
//(3)  show the window
//(4)  run the application object to watch and handle events
